from setuptools import setup, find_packages

setup(
    name='RPi-cluster-tracking',
    version='1.0',
    author='Samarth Gupta',
    author_email='me@samteck.net',
    packages=find_packages(),
)
